package com.wykd.config;

import java.io.File;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

public class WConfiguration {

	//将连接数据库信息放到WConfiguration中
	
	//将接口，对应的mapper放到WConfiguration中
	private Map<String,WMapper> batisMapper = new HashMap<String,WMapper>();
	
	
	public WConfiguration() {
		doScanMapper();
	}
	
	/**
	 * 扫描 xml文件，将信息保存在batisMapper中
	 */
	public void doScanMapper() {
		
		
//		scanPackageClass("");
		
		WMapper mapper01 = new WMapper();
		mapper01.setMethodId("com.wykd.dao.IUserDao");
		mapper01.setNamespace("getUserList");
		mapper01.setSql("select * from sec_user");
		mapper01.setReturnType("com.wykd.vo.User");
		batisMapper.put("com.wykd.dao.IUserDao.getUserList", mapper01);
		
		
		WMapper mapper02 = new WMapper();
		mapper02.setMethodId("com.wykd.dao.IUserDao");
		mapper02.setNamespace("selectUserById");
		mapper02.setSql("select * from sec_user where id = 1");
		mapper02.setReturnType("com.wykd.vo.User");
		batisMapper.put("com.wykd.dao.IUserDao.selectUserById", mapper02);
	}

	public Map<String, WMapper> getBatisMapper() {
		return batisMapper;
	}
	
	private void scanPackageClass(String packagePath) {
		
		packagePath = packagePath.replaceAll("\\.", "/");
//		System.out.println(packagePath);
		URL url = this.getClass().getClassLoader().getResource(packagePath);
//		System.out.println(url.getFile());
		
		File packageFile = new File(url.getFile());
		File[] files = packageFile.listFiles();
		for (int i = 0; i < files.length; i++) {
			File file = files[i];
			if(!file.isDirectory()) {
				
//				System.out.println("扫描的文件名为："+packagePath +"/"+ file.getName());
				
				String absolutePaht = (packagePath +"/"+ file.getName())
						.replaceAll("/", "\\.")
						.replaceAll(".class", "");
				
				
//				System.out.println("扫描的文件名为======================>"+absolutePaht);
				
			}else {
				scanPackageClass(packagePath +"/"+ file.getName());
			}
		}
		
		
	}
	
	
}
