package com.wykd.sqlsession;

import java.io.IOException;
import java.io.InputStream;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import com.wykd.vo.User;

public class WExecutor {
	
	private Properties properties = new Properties(); // 配置文件
	
	private static String url ;
	private static String username ;
	private static String password ;
	private static String driver;
	
	public WExecutor() {
		getScanPackagePath();
	}
	
	
	public <T> List<T> selectData(String sql, Object[] args) {
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<User> list = new ArrayList();
		try {
			Connection conn = getConn();
			pstmt = (PreparedStatement) conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			list = transform2Object(rs);
			
			return (List<T>) list;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return (List<T>) list;

	}


	private List<User> transform2Object(ResultSet rs) throws SQLException {
		
		List<User> list = new ArrayList();
		
		int col = rs.getMetaData().getColumnCount();
		
		ResultSetMetaData rsmd = rs.getMetaData();
		
//		System.out.println(rsmd.getColumnName(1));
//		System.out.println("============================");
		while (rs.next()) {
			User user = new User();
			for (int i = 1; i <= col; i++) {
//				System.out.print(rs.getString(i) + "\t");
//				
//				if ((i == 2) && (rs.getString(i).length() < 8)) {
//					System.out.print("\t");
//				}
				
				
				if("id".equalsIgnoreCase(rs.getMetaData().getColumnName(i))) {
					user.setId(rs.getInt(i));
				}
				if("username".equalsIgnoreCase(rs.getMetaData().getColumnName(i))) {
					user.setUsername(rs.getString(i));
				}
				if("password".equalsIgnoreCase(rs.getMetaData().getColumnName(i))) {
					user.setPassword(rs.getString(i));
				}
				
				
			}
			list.add(user);
//			System.out.println("");
		}
//		System.out.println("============================");
		
		
		return list;
	}

	private static Connection getConn() {
//		String driver = "com.mysql.jdbc.Driver";
//		String url = "jdbc:mysql://120.78.168.84:3306/wykddb?useSSL=false";
//		String username = "root";
//		String password = "2048";
		Connection conn = null;
		try {
			Class.forName(driver); // classLoader,加载对应驱动
			conn = (Connection) DriverManager.getConnection(url, username, password);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return conn;
	}

	
	
	private void getScanPackagePath() {

		InputStream inputStream = this.getClass().getClassLoader().getResourceAsStream("jdbc.properties");
		try {
			properties.load(inputStream);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		this.driver = properties.getProperty("db.driverClass");
		this.url = properties.getProperty("db.url");
		this.username = properties.getProperty("db.username");
		this.password = properties.getProperty("db.password");
	}
}
