package com.wykd.dao;

import java.util.List;

import com.wykd.vo.User;

public interface IUserDao {

	/**
	 * 
	 * @return
	 */
	public List<User> getUserList();
	
	public  User getUserById();
	
}
