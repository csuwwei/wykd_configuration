package com.wykd.proxy;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.util.Collection;

import com.wykd.config.WConfiguration;
import com.wykd.sqlsession.WSqlSession;

public class MybatisHandler implements InvocationHandler{

	private WSqlSession sqlSession;
	
	
	public MybatisHandler(WSqlSession sqlSession) {
		this.sqlSession = sqlSession;
	}
	
	@Override
	public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
		
		Object ret = null;
		//根据返回的类型，执行sqlSession的方法
		Class<?> clazz = method.getReturnType();
		
		if(Collection.class.isAssignableFrom(clazz)) {
			ret = sqlSession.selectList(method.getDeclaringClass().getName()+"."+method.getName(), args);
		}else {
			ret = sqlSession.selectOne(method.getDeclaringClass().getName()+"."+method.getName(), args);
		}
		return ret;
	}

	
	
	
	
	
	
	
}
