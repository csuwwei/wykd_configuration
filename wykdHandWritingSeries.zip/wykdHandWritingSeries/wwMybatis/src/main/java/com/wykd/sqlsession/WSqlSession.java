package com.wykd.sqlsession;

import java.util.List;

import com.wykd.vo.User;

public interface WSqlSession {

	
	User selectOne(String statement,Object[] args);
	
	
	List<User> selectList(String statement,Object[] args);


	
	
}
