package com.wykd.sqlsession;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import com.wykd.config.WConfiguration;
import com.wykd.config.WMapper;
import com.wykd.vo.User;

public class DefaultSqlSession implements WSqlSession {

	private WExecutor executor = new WExecutor();
	
	private WConfiguration config;
	
	public DefaultSqlSession(WConfiguration config) {
		this.config = config;
	}
	
	
	
	public WConfiguration getConfig() {
		return config;
	}

	public User selectOne(String statement, Object[] args) {
		System.out.println(statement);
		
		
		List<User> list = selectList(statement ,args);
		
		
		return list.get(0);
	}

	@Override
	public List<User> selectList(String statement,Object[] args) {
		//根据statement解析sql
		Map<String, WMapper> mapper = config.getBatisMapper();
		WMapper wMapper = (WMapper) mapper.get(statement);
		String sql  = wMapper.getSql();
//		ResultSet result = null;
		
		return executor.selectData(sql ,args);
//		try {
//			result = executor.selectData(sql ,args);
//			while(result.next()) {
//				System.out.println(result.getString("username"));
//			}
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		 //将ResultSet转化成 mapper.xml配置的returnType对象
//		 
//		 
//		 return null;
	}







}
