package com.wykd.proxy;

import java.lang.reflect.Proxy;

import com.wykd.config.WConfiguration;
import com.wykd.dao.IUserDao;
import com.wykd.sqlsession.WSqlSession;

public class DynamicProxy {

	private  WSqlSession sqlSession ;
	
	public DynamicProxy() {
		
	}
	
	public DynamicProxy(WSqlSession sqlSession ) {
		this.sqlSession = sqlSession;
	}
	
	public static void main(String[] args) {
		System.out.println(new DynamicProxy().getClass().getCanonicalName());
	}
	
	public Object getInstance(Class<IUserDao> class1) {
		Object obj = Proxy.newProxyInstance(class1.getClassLoader(), new Class[] {class1}, 
				new MybatisHandler(sqlSession));
		return obj;
	}

	
	
}
