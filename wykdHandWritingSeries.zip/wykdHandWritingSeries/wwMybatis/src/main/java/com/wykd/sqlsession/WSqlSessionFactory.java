package com.wykd.sqlsession;

import com.wykd.config.WConfiguration;

public class WSqlSessionFactory {

	
	
	public static WSqlSession openSession(WConfiguration config) {
		return new DefaultSqlSession(config);
	}

}
