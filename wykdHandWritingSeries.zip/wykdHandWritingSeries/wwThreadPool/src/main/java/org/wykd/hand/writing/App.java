package org.wykd.hand.writing;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Hello world!
 */
public class App {
    public static void main(String[] args) {


        ExecutorService executorService = Executors.newFixedThreadPool(5);



        int taskNum = 6;

        WFixedSizeThreadPool pool = new WFixedSizeThreadPool(3,taskNum);

        for (int i = 0; i < taskNum; i++) {

            pool.submit(new Runnable() {
                @Override
                public void run() {
                    System.out.println("任务开始进行。。。。");
                }
            });
        }

        //任务添加完毕后，调用shutdown方法，不再添加任务到连接池的阻塞队列中。
        pool.shutdown();


    }



}
