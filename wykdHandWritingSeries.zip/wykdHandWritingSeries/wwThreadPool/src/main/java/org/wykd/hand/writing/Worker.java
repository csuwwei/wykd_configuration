package org.wykd.hand.writing;

public class Worker extends Thread{

    private WFixedSizeThreadPool pool;

    public Worker(WFixedSizeThreadPool pool){
        this.pool = pool;
    }

    /**
     * 当执行start方法时，会触发该方法
     */
    public void run() {
        int taskCount = 0;


        while(this.pool.working  || this.pool.taskQuene.size()>0){
            Runnable task = null;

            try {
                //从任务队列中拿到新任务，并执行任务
                if(this.pool.working){
                    //阻塞方法, 在任务添加完毕之前，需要阻塞等待。
                    task =  this.pool.taskQuene.take();
                }else{
                    //队列中存在，则取出来，不存在，则往下执行。
                    task =  this.pool.taskQuene.poll();
                }

            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            if(task != null){
                task.run();  //执行任务
                System.out.println(Thread.currentThread().getName() + taskCount++);
            }


        }




    }
}
