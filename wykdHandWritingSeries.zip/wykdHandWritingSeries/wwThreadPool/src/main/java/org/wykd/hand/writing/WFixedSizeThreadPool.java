package org.wykd.hand.writing;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class WFixedSizeThreadPool {

    /**
     * 存放任务的队列
     */
    public BlockingQueue<Runnable> taskQuene;

    /**
     * worker 代表一个线程
     */
    public List<Worker> workers;

    //线程池是否工作的标识
    public volatile boolean working = true;

    /**
     * @param poolSize      线程池大小
     * @param taskQueneSize 任务队列大小
     */
    public WFixedSizeThreadPool(int poolSize, int taskQueneSize) {

        if (poolSize <= 0 || taskQueneSize <= 0) {
            throw new IllegalArgumentException("参数错误");
        }
        taskQuene = new LinkedBlockingQueue(taskQueneSize);
        this.workers = Collections.synchronizedList(new ArrayList<Worker>());

        for (int i = 0; i < poolSize; i++) {
            //初始化时，新增指定个数的线程
            Worker w = new Worker(this);
            w.start();  //会触发worker的run方法
            this.workers.add(w);
        }

    }

    /**
     * 参考多线程的submit方法
     */
    public boolean submit(Runnable task) {
        //将task添加到 任务队列中
        if (!this.working) {
            return false;
        }
        return this.taskQuene.offer(task);
    }

    public void shutdown() {
        this.working = false;

        //把阻塞的线程中断
        for (Thread t : this.workers
        ) {
            if (t.getState().equals(Thread.State.BLOCKED)
                    || t.getState().equals(Thread.State.WAITING)
                    || t.getState().equals(Thread.State.TIMED_WAITING)) {
                t.interrupt();
            }
        }
    }


}
